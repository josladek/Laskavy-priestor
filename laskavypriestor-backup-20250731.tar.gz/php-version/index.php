<?php
// Redirect to pages/index.php
header('Location: pages/index.php');
exit;
?>

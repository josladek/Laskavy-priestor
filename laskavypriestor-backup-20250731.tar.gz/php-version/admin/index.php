<?php
// Simple redirect to dashboard.php
header('Location: dashboard.php');
exit;
?>